# Simulacro modelo — árbol de regresión (semana 12)

Este es el estándar que debes igualar: primero la hoja de cifras, después la figura, después las
preguntas. Imita la forma, nunca el contenido: tu simulacro usa otra empresa, otro sector y otras
cifras.

## 1. La hoja de cifras (interna, no se muestra)

LibroMax (cadena de librerías) · target: ventas del primer mes, en miles de ejemplares ·
predictoras: seguidores_autor (miles), precio (miles de pesos), paginas, es_saga, calificacion ·
1.800 títulos de entrenamiento. Árbol asimétrico, 5 hojas, profundidad 3 solo por la rama derecha;
`precio < 40` se repite en los nodos 2 y 6 (ramas distintas → la pregunta de conteo suma las hojas
4 y 12).

| Nodo | Tipo | Corte | Promedio | n | % |
|---|---|---|---|---|---|
| 1 | raíz | ¿seguidores_autor ≥ 80? (sí ←) | 16.8 | 1.800 | 100 |
| 2 | interno | ¿precio < 40? | 29.5 | 700 | 39 |
| 4 | hoja | — | 34.2 | 420 | 23 |
| 5 | hoja | — | 22.5 | 280 | 16 |
| 3 | interno | ¿es_saga = 1? | 8.7 | 1.100 | 61 |
| 6 | interno | ¿precio < 40? | 14.1 | 500 | 28 |
| 12 | hoja | — | 15.8 | 310 | 17 |
| 13 | hoja | — | 11.4 | 190 | 11 |
| 7 | hoja | — | 4.1 | 600 | 33 |

Verificación: 420+280 = 700; 310+190 = 500; 500+600 = 1.100; 700+1.100 = 1.800 ✓ · % de hojas
23+16+17+11+33 = 100 ✓ · promedios ponderados: (420·34.2+280·22.5)/700 = 29.5 ✓;
(310·15.8+190·11.4)/500 = 14.1 ✓; (500·14.1+600·4.1)/1.100 ≈ 8.7 ✓; (700·29.5+1.100·8.7)/1.800 ≈
16.8 ✓ · conteo precio < 40: 420+310 = 730 ✓.

## 2. La figura (el SVG que se entrega como artefacto)

```svg
<svg viewBox="0 0 940 560" xmlns="http://www.w3.org/2000/svg" font-family="Helvetica, Arial, sans-serif">
  <rect width="940" height="560" fill="#ffffff"/>
  <!-- aristas -->
  <g stroke="#94a3b8" stroke-width="1.6" fill="none">
    <line x1="470" y1="98" x2="240" y2="152"/><line x1="470" y1="98" x2="700" y2="152"/>
    <line x1="240" y1="220" x2="120" y2="287"/><line x1="240" y1="220" x2="360" y2="287"/>
    <line x1="700" y1="220" x2="580" y2="287"/><line x1="700" y1="220" x2="820" y2="287"/>
    <line x1="580" y1="355" x2="480" y2="422"/><line x1="580" y1="355" x2="680" y2="422"/>
  </g>
  <text x="330" y="122" font-size="13" fill="#475569" font-weight="bold">si</text>
  <text x="600" y="122" font-size="13" fill="#475569" font-weight="bold">no</text>
  <!-- nodo: numero encima, caja con promedio / n / % ; condicion bajo los internos -->
  <!-- plantilla de nodo -->
  <g text-anchor="middle">
    <!-- 1 -->
    <text x="470" y="26" font-size="12" fill="#64748b">1</text>
    <rect x="395" y="32" width="150" height="66" rx="8" fill="#f1f5f9" stroke="#64748b"/>
    <text x="470" y="56" font-size="15" font-weight="bold" fill="#1f2937">16.8</text>
    <text x="470" y="74" font-size="12.5" fill="#1f2937">n = 1.800</text>
    <text x="470" y="90" font-size="12.5" fill="#1f2937">100 %</text>
    <text x="470" y="113" font-size="13" fill="#1f2937">&#191;seguidores_autor &#8805; 80?</text>
    <!-- 2 -->
    <text x="240" y="146" font-size="12" fill="#64748b">2</text>
    <rect x="165" y="152" width="150" height="66" rx="8" fill="#f1f5f9" stroke="#64748b"/>
    <text x="240" y="176" font-size="15" font-weight="bold" fill="#1f2937">29.5</text>
    <text x="240" y="194" font-size="12.5" fill="#1f2937">n = 700</text>
    <text x="240" y="210" font-size="12.5" fill="#1f2937">39 %</text>
    <text x="240" y="233" font-size="13" fill="#1f2937">&#191;precio &lt; 40?</text>
    <!-- 3 -->
    <text x="700" y="146" font-size="12" fill="#64748b">3</text>
    <rect x="625" y="152" width="150" height="66" rx="8" fill="#f1f5f9" stroke="#64748b"/>
    <text x="700" y="176" font-size="15" font-weight="bold" fill="#1f2937">8.7</text>
    <text x="700" y="194" font-size="12.5" fill="#1f2937">n = 1.100</text>
    <text x="700" y="210" font-size="12.5" fill="#1f2937">61 %</text>
    <text x="700" y="233" font-size="13" fill="#1f2937">&#191;es_saga = 1?</text>
    <!-- 4 -->
    <text x="120" y="281" font-size="12" fill="#64748b">4</text>
    <rect x="45" y="287" width="150" height="66" rx="8" fill="#5ea4e3" stroke="#64748b"/>
    <text x="120" y="311" font-size="15" font-weight="bold" fill="#0b2545">34.2</text>
    <text x="120" y="329" font-size="12.5" fill="#0b2545">n = 420</text>
    <text x="120" y="345" font-size="12.5" fill="#0b2545">23 %</text>
    <!-- 5 -->
    <text x="360" y="281" font-size="12" fill="#64748b">5</text>
    <rect x="285" y="287" width="150" height="66" rx="8" fill="#8dbfec" stroke="#64748b"/>
    <text x="360" y="311" font-size="15" font-weight="bold" fill="#0b2545">22.5</text>
    <text x="360" y="329" font-size="12.5" fill="#0b2545">n = 280</text>
    <text x="360" y="345" font-size="12.5" fill="#0b2545">16 %</text>
    <!-- 6 -->
    <text x="580" y="281" font-size="12" fill="#64748b">6</text>
    <rect x="505" y="287" width="150" height="66" rx="8" fill="#f1f5f9" stroke="#64748b"/>
    <text x="580" y="311" font-size="15" font-weight="bold" fill="#1f2937">14.1</text>
    <text x="580" y="329" font-size="12.5" fill="#1f2937">n = 500</text>
    <text x="580" y="345" font-size="12.5" fill="#1f2937">28 %</text>
    <text x="580" y="368" font-size="13" fill="#1f2937">&#191;precio &lt; 40?</text>
    <!-- 7 -->
    <text x="820" y="281" font-size="12" fill="#64748b">7</text>
    <rect x="745" y="287" width="150" height="66" rx="8" fill="#e3effb" stroke="#64748b"/>
    <text x="820" y="311" font-size="15" font-weight="bold" fill="#1f2937">4.1</text>
    <text x="820" y="329" font-size="12.5" fill="#1f2937">n = 600</text>
    <text x="820" y="345" font-size="12.5" fill="#1f2937">33 %</text>
    <!-- 12 -->
    <text x="480" y="416" font-size="12" fill="#64748b">12</text>
    <rect x="405" y="422" width="150" height="66" rx="8" fill="#aed2f2" stroke="#64748b"/>
    <text x="480" y="446" font-size="15" font-weight="bold" fill="#0b2545">15.8</text>
    <text x="480" y="464" font-size="12.5" fill="#0b2545">n = 310</text>
    <text x="480" y="480" font-size="12.5" fill="#0b2545">17 %</text>
    <!-- 13 -->
    <text x="680" y="416" font-size="12" fill="#64748b">13</text>
    <rect x="605" y="422" width="150" height="66" rx="8" fill="#c6e0f7" stroke="#64748b"/>
    <text x="680" y="446" font-size="15" font-weight="bold" fill="#0b2545">11.4</text>
    <text x="680" y="464" font-size="12.5" fill="#0b2545">n = 190</text>
    <text x="680" y="480" font-size="12.5" fill="#0b2545">11 %</text>
  </g>
  <text x="470" y="530" font-size="13" fill="#475569" text-anchor="middle">LibroMax &#183; arbol de regresion: ventas del primer mes (miles de ejemplares) &#183; 1.800 titulos de entrenamiento</text>
  <text x="470" y="548" font-size="12" fill="#94a3b8" text-anchor="middle">En cada pregunta, la rama izquierda responde &#171;si&#187; &#183; hojas sombreadas: mas oscuro = mas ventas</text>
</svg>
```

## 3. El simulacro (lo que ve el estudiante)

### Simulacro · Árboles de regresión · Semana 12

**Contexto.** LibroMax, una cadena de librerías, entrenó un árbol de regresión con 1.800 títulos
de su catálogo para decidir cuántos ejemplares pedir de cada lanzamiento: el target es ventas del
primer mes (miles de ejemplares) y las predictoras son seguidores_autor (miles), precio (miles de
pesos), paginas, es_saga (1 = pertenece a una saga) y calificacion. En la figura, el número sobre
cada caja identifica el nodo; dentro van el promedio de ventas del grupo, cuántos títulos de
entrenamiento caen ahí (n) y qué % son. En cada pregunta del árbol, la rama izquierda responde
«sí».

[FIGURA]

**1.** El equipo de datos documenta el modelo y debe reportar la profundidad del árbol. ¿Cuál es
y por qué?
a) 2: las preguntas que responde un título de autor muy seguido antes de quedar en su hoja.
b) 3: el camino más largo de preguntas — seguidores, saga y precio — que hay hasta una hoja.
c) 5: la profundidad de un árbol corresponde al número de hojas en que queda partido el espacio.
d) 3: porque todo título, caiga en la rama que caiga, responde tres preguntas antes de su hoja.

**2.** En la misma documentación piden el tamaño del árbol: su número de hojas. ¿Cuántas tiene y
cuáles son?
a) 4: los nodos 1, 2, 3 y 6 — los que concentran la información de todos los títulos.
b) 9: todos los nodos del dibujo cuentan como hojas porque cada uno agrupa títulos.
c) 5: una por cada predictora — seguidores, precio, páginas, saga y calificación.
d) 5: los nodos 4, 5, 12, 13 y 7 — los grupos donde el árbol ya no hace más preguntas.

**3.** Tomas del catálogo un título con 95 mil seguidores, precio de 52 mil, 300 páginas y sin
saga. ¿En qué hoja cae y cuántos títulos de entrenamiento lo acompañan?
a) En la hoja 5, con 280 títulos: supera el corte de seguidores pero su precio no baja de 40 mil.
b) En la hoja 4, con 420 títulos: su autor supera el corte y va al lado izquierdo del árbol.
c) En la hoja 13, con 190 títulos: al no ser de saga, el árbol lo manda al grupo de casos raros.
d) En la hoja 5, con 280 títulos: es el grupo que recibe a los títulos sin saga del catálogo.

**4.** Llega un lanzamiento nuevo: 25 mil seguidores, pertenece a una saga y cuesta 35 mil.
¿Cuántos ejemplares (miles) pronostica el árbol para su primer mes?
a) 34.2: cuesta menos de 40 mil, y esa es la hoja que recoge a los títulos baratos del catálogo.
b) 15.8: el árbol promedia las hojas 12 y 13 de la rama de las sagas para pronosticarlo.
c) 15.8: sin el corte de seguidores entra al nodo 3, y la saga y su precio lo dejan en el 12.
d) 8.7: se queda con el promedio del nodo 3, el grupo de los autores menos conocidos.

**5.** La gerente de compras pregunta cuántos títulos de entrenamiento cuestan menos de 40 mil.
Con las hojas del árbol, ¿qué le responde la analista?
a) 420: los de la hoja 4, la única hoja del árbol que responde «sí» a la pregunta por el precio.
b) 730: los 420 de la hoja 4 más los 310 de la hoja 12, las dos hojas que quedan bajo ese corte.
c) 1.200: los 700 del nodo 2 más los 500 del nodo 6, las dos ramas que preguntan por el precio.
d) 730: los 420 de la hoja 4 más los 310 de la hoja 12, por ser las dos hojas más grandes.

Responde con las letras, por ejemplo: 1a, 2b, 3c, 4d, 5a.

## 4. Clave y verificación (interna)

Clave: **1b · 2d · 3a · 4c · 5b** — letras a1 b2 c1 d1, sin tres seguidas, sin escaleras ✓.

- 1: dos opciones comparten el 3 (b correcta; d falla porque la rama izquierda solo hace 2
  preguntas) ✓ regla 3.
- 2: dos comparten el 5 (d correcta; c es la trampa «una por variable» — y de paso enseña que
  páginas y calificación no aparecen en el árbol) ✓.
- 3: dos comparten hoja 5 / 280 (a correcta; d falla porque a ese título la pregunta de la saga
  nunca se le hace) ✓. El camino se lee en la figura: sí en seguidores, no en precio.
- 4: dos comparten 15.8 (c correcta; b falla porque nunca se promedian hojas: se lee la del caso).
  La trampa a (34.2) es la hoja llamativa cuyo corte de precio está en una rama que este título
  nunca visita ✓.
- 5: dos comparten 730 (b correcta; d da el número con un porqué falso: las dos hojas más grandes
  son la 7 y la 4). Obliga a sumar hojas de ramas distintas ✓.
- Toda cifra usada (34.2, 22.5, 15.8, 8.7, 280, 420, 190, 310, 700, 500, 730) se lee en la figura
  ✓. Opciones de largo parejo por pregunta ✓. Roles: equipo de datos, gerente de compras, la
  analista ✓. Sector ficticio, sin Cóndor ni casos de clase ✓.
