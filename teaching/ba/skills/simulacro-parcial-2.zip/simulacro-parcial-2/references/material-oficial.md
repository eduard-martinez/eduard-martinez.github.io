# Material oficial del parcial 2: qué es examinable por tema

Todo cuelga de la página del curso: https://eduard-martinez.github.io/teaching/business-analytics-es/
Las semanas 10 y 13 tienen teoría escrita extensa; las semanas 11 y 12 se estudian con video y
aplicaciones interactivas, y su contenido examinable (leer el árbol dibujado) está completo aquí.
En la clave del simulacro cita la sección o la pieza («*Repasa:* …») tal como aparece abajo.

## Semana 6 — Leer los gráficos del EDA
Teoría: …/week-06/theory/week-06.html · Secciones citables: «Las cuatro dimensiones de la
calidad», «Problema 1: valores faltantes», «Problema 2: outliers», «Problema 3: el error más
silencioso», «Qué es la EDA».
Ideas examinables (en el parcial 2, siempre desde una figura): qué representa una fila va primero
· el histograma bimodal: el promedio cae en el valle y no representa a nadie — se resume por
segmento · promedio contra mediana cuando hay cola u outliers · el outlier que marca la regla del
IQR puede ser error o cliente valioso: el negocio lo distingue, no se elimina en bloque · el vacío
que significa «no aplica» contra el dato perdido; el faltante no aleatorio sesga si se imputa ·
«Norte» y «norte» parten los totales sin avisar (dos barras que deberían ser una) · tasas por
tramo: qué grupo se comporta distinto y qué decisión habilita · los datos sucios no dan error, dan
respuestas confiadas y falsas.
Distractores típicos: reportar el promedio de una bimodal como «el cliente típico» · eliminar todo
lo que sale de los bigotes · imputar sin preguntar por qué falta · leer dos categorías duplicadas
como dos grupos reales · corregir el original a mano.

## Semana 10 — Evaluar modelos: train/test, baseline y métricas
Teoría: …/week-10/theory/week-10.html · Secciones citables: «El estudiante que se sabía el parcial
de memoria», «El examen: entrenamiento vs. prueba», «El baseline: la regla ingenua que hay que
vencer», «Las métricas: cómo se califica una predicción» (videos 4 y 5), «El umbral y el AUC».
Ideas examinables: medirse en preguntas conocidas mide memoria, no comprensión → nunca evaluar con
los datos de entrenamiento · 80/20, el test se usa una sola vez; con datos en el tiempo no se
parte al azar (fuga de información) · sobreajuste: excelente en train, malo en test · baseline =
la predicción sin información (clase mayoritaria o promedio de train); un modelo aporta solo lo
que le gana al baseline · con clases desbalanceadas la accuracy se infla sola (98 % sin detectar
ningún fraude) · la matriz: la primera palabra dice si el modelo acertó, la segunda qué predijo
(un FP es «predijo positivo… y falló») · accuracy = (TP+TN)/total; precisión = TP/(TP+FP), «de los
que marcó, ¿cuántos eran?»; recall = TP/(TP+FN), «de los reales, ¿cuántos encontró?» · cuál métrica
importa la decide el costo del error (negocio, no algoritmo): impago caro → precisión; fraude o
retención → recall · umbral bajo = más marcados = sube recall y baja precisión · AUC mide cómo
ordena (0.5 = azar); solo existe si hay probabilidades · MAE = error promedio en las unidades del
target, fácil de comunicar; RMSE castiga los errores grandes, siempre RMSE ≥ MAE y la brecha
delata fallas graves ocasionales · el baseline de regresión es el promedio de train.
Distractores típicos: celebrar una accuracy alta sin baseline con clases desbalanceadas · evaluar
en train y reportarlo como desempeño · confundir precisión con recall (o FP con FN) · creer que
bajar el umbral sube la precisión · calcular AUC a una regla que solo dice sí/no · un RMSE menor
que el MAE · leer el MAE sin unidades.
Decisiones con dinero (de la clase, como forma de razonar, no sus cifras): envíos = TP + FP; costo
= envíos × costo unitario; costo por encontrado = costo ÷ TP; el modelo se adopta si el valor de
los encontrados supera el costo — y a veces la línea base gana.

## Semana 11 — Árboles de clasificación (leer el árbol)
Teoría (video + playground): …/week-11/theory/week-11.html · Citables: «El video de la semana»,
«Explóralo tú mismo: entrena tu primer árbol», las láminas y el script de la clase.
Ideas examinables: el árbol decide como un analista con prisa — pregunta primero lo que más separa
· nodo de decisión contra hoja; en cada pregunta la rama izquierda responde «sí» · la hoja guarda
la clase mayoritaria de su grupo y el dibujo muestra los conteos (cuántos 0 y cuántos 1, la n y el
% del total) · profundidad = el camino MÁS LARGO de preguntas hasta una hoja (un árbol asimétrico
tiene ramas más cortas) · tamaño = número de hojas · para clasificar un caso se recorre el árbol
pregunta por pregunta: las preguntas de las ramas que no toma nunca se le hacen · el árbol puede
usar pocas variables aunque le den muchas, y puede repetir una variable en varios nodos · más
profundidad = memoriza train y falla en test (sobreajuste); se verifica comparando train contra
test · del árbol sale una matriz de confusión en el test y de ahí la decisión con costos ·
generalizar: que aprenda el patrón, no que memorice la respuesta.
Distractores típicos: profundidad contada por la rama corta · «una hoja por variable» · contar
todos los nodos como hojas · creer que toda variable de la base aparece en el árbol, o que ninguna
se repite · mandar un caso a una hoja por una condición que su rama nunca pregunta · leer el % del
total como «probabilidad de acierto» · elegir el árbol por su desempeño en train.

## Semana 12 — Árboles de regresión (leer el árbol)
Teoría (video + playground): …/week-12/theory/week-12.html · Citables: «El video de la semana»,
«Explóralo tú mismo: el árbol que predice números», las láminas y el script de la clase.
Ideas examinables: mismo CART, ahora el target es un número — la hoja ya no guarda una clase sino
el PROMEDIO de su grupo · el pronóstico es una escalera: el árbol solo puede predecir tantos
valores distintos como hojas tiene · para pronosticar un caso nuevo se recorre el árbol y se lee el
promedio de su hoja (nunca se promedian dos hojas) · el error se mide con MAE en las unidades del
negocio y se compara contra el baseline (el promedio de train) · la brecha MAE–RMSE delata errores
grandes ocasionales · el árbol jerarquiza: la variable que más separa puede repetirse con cortes
distintos mientras otras no aparecen · límite honesto: el árbol pronostica el promedio del grupo,
no el caso extremo — ningún modelo pronostica un éxito atípico.
Distractores típicos: promediar las hojas de una rama para pronosticar · leer la n de la hoja como
la predicción · «una hoja por variable» · la profundidad por la rama corta · creer que el árbol
«acierta o falla» en regresión (no hay acierto: hay error en unidades) · comparar el MAE de dos
modelos sin el baseline.

## Semana 13 — Clustering (k-means)
Teoría: …/week-13/theory/week-13.html · Secciones citables: «Se acabaron las respuestas», «¿Por
qué segmentar?», «k-means: la máquina de las bodegas», «¿Cuántos clusters? El codo, la silueta y
el negocio», «Perfilamiento: de números a decisiones», «Errores frecuentes».
Ideas examinables: no supervisado = no hay target ni «accuracy»; se evalúa con compactación
(WCSS), silueta y, sobre todo, criterio de negocio · similitud = cercanía: cada observación es un
punto y cada eje una variable · escalar ANTES de agrupar es obligatorio: sin `scale()` la variable
de rango grande (pesos) domina la distancia y el clustering refleja unidades, no comportamiento ·
k-means en 4 pasos (bodegas): poner k centroides, asignar cada punto al más cercano, mover cada
centroide al promedio de los suyos, repetir hasta converger · el centroide es un promedio, no un
cliente: se mira la dispersión antes de describir el segmento · la WCSS SIEMPRE baja al agregar
clusters; el codo es donde deja de bajar con ganas (orienta, no decide) · la silueta va de −1 a +1
por punto (cerca de +1 bien asignado, 0 en la frontera, negativo probablemente en el cluster
equivocado) y su promedio sí tiene un máximo · si el codo sugiere un k y la silueta otro, se
perfilan ambos y gana el que produzca segmentos nombrables y accionables · perfilamiento: tabla de
promedios por cluster + tamaños + nombre de negocio («VIP dormidos», no «Grupo A») · un cluster
pequeño puede ser ruido o un nicho valioso: el perfil decide · nstart = 25 y set.seed contra la
mala suerte del arranque · solo variables numéricas relevantes: los ID numéricos no miden distancia
· k-means asume grupos redondos y es sensible a outliers · de vista: jerárquico (dendrograma, no
pide k), DBSCAN (formas raras, separa outliers).
Distractores típicos («los seis pecados»): no escalar · elegir k donde la WCSS es mínima (sería el
k máximo) · elegir k solo con el codo · meter el ID como variable · reportar clusters sin perfilar
· leer el centroide como el cliente típico · tratar la asignación de un punto fronterizo como
certeza · creer que el algoritmo decide cuántos grupos hay.

## Lo que NO entra en el parcial 2
Código y sintaxis de R (el parcial es de lectura e interpretación, no de programación) · poda y
sus parámetros (cp, maxdepth: el taller los usa, el parcial no los examina) · validación cruzada
en detalle · boosting, xgboost, redes, PCA, regularización · probabilidades por hoja · fórmulas de
impureza (Gini, entropía) · DBSCAN y jerárquico más allá de qué resuelven. Y nunca «el humano»: se
nombra el rol (la analista, el científico de datos, la gerente).
