# Cómo se construye cada figura (cifras primero, dibujo después)

## La hoja de cifras (siempre, antes de dibujar)

Antes de dibujar, escribe para ti (no para el estudiante) la historia completa en números y
verifícala:

- **Árbol:** total de observaciones; para cada nodo su número (raíz 1, hijos de k son 2k y 2k+1),
  su condición de corte, su valor (promedio, o conteos por clase), su n y su % del total. Verifica:
  las n de los hijos suman la del padre; los % de las hojas suman 100; el valor de cada nodo
  interno es el promedio ponderado (o la suma de conteos) de sus hijos; las hojas quedan ordenadas
  de forma creíble (el grupo «bueno» tiene el valor alto).
- **Clusters:** para cada grupo su centroide (una cifra por eje), su tamaño y su nombre tentativo;
  el punto nuevo, si lo hay, con sus coordenadas. Verifica: el punto nuevo queda inequívocamente
  más cerca de UN centroide; los grupos no se traslapan tanto que la pregunta sea ambigua.
- **Codo + silueta:** la WCSS para k = 1…8 (estrictamente decreciente, con caídas grandes al
  principio y migajas al final) y la silueta promedio para k = 2…8 (con un máximo claro). Decide si
  codo y silueta coinciden o discrepan en un paso: la discrepancia da la mejor pregunta.
- **EDA:** los conteos de cada barra o tramo (suman el total), el promedio y la mediana (coherentes
  con la forma: en una cola derecha, promedio > mediana; en una bimodal, el promedio cae en el
  valle), el outlier con su valor.
- **Matriz de confusión:** TP, FP, FN, TN que suman el total del test; calcula tú accuracy,
  precisión, recall (y el baseline de clase mayoritaria) con dos decimales y guárdalos para la
  clave. Si comparas dos modelos, que ninguno domine en todo: uno gana precisión, otro recall.

Todo número que una pregunta use sale de esta hoja y se puede leer en la figura (o calcular con
dos o tres cifras de ella). Si una pregunta necesita un dato que la figura no muestra, cambia la
figura o cambia la pregunta.

## Reglas comunes del SVG

Un solo `<svg>` entregado como artefacto. `viewBox` de unos 900×480 (más alto si el árbol tiene
4 niveles). Fondo blanco explícito (`<rect>` del tamaño total, `fill="#ffffff"`). Texto en
`font-family="Helvetica, Arial, sans-serif"`, tamaño ≥ 12 del viewBox, color `#1f2937`. Colores
accesibles y sobrios (azul `#378add`, verde `#2e9e73`, naranja `#f97316`, gris `#94a3b8`); nunca
codifiques información solo con color: acompaña con forma, etiqueta o posición. Todo rotulado: ejes
con nombre y unidades, leyenda, títulos de panel. Sin degradados ni decoración.

## Tipo 1 — El árbol (clasificación o regresión), estilo de la clase

Imita el dibujo que los estudiantes vieron en clase (`rpart.plot` con `nn = TRUE, extra = 101`):

- Cada nodo es una **caja redondeada** con su **número encima** (pequeño, gris). Dentro, tres
  líneas: el **valor** en negrita (regresión: el promedio; clasificación: la clase y debajo los
  conteos «0: 830 · 1: 170»), la **n** y el **% del total**.
- Bajo cada nodo interno, su **condición de corte** (`precio < 40`); la **rama izquierda responde
  «sí»** — dilo en el contexto y rotula «sí»/«no» en las dos ramas de la raíz.
- Hazlo **asimétrico** (la profundidad máxima solo por una rama: da la trampa de la rama corta),
  con **4 a 6 hojas**, y — si vas a preguntar un conteo por condición — **repite una variable con
  el mismo corte en dos nodos de ramas distintas**, para que la respuesta obligue a sumar dos
  hojas que no son hermanas.
- Sombrea las hojas con una intensidad proporcional a su valor (más oscuro = más alto) y deja los
  nodos internos más claros.

## Tipo 2 — Dispersión con clusters (semana 13)

Dos ejes con nombre y unidades (dos variables de comportamiento, p. ej. «compras por mes» y
«gasto promedio (miles $)»; una escalada si la pregunta es sobre escalar). **3 o 4 grupos**, cada
uno con color Y forma distintos (círculo, triángulo, cuadrado), 15–25 puntos por grupo, separados
pero con 1 o 2 puntos en una frontera. **Centroides marcados con una ✕ grande** del color del
grupo. Si la batería lo pide, un **punto nuevo marcado con ★** y rotulado («cliente nuevo»).
Leyenda con el tamaño de cada grupo («Grupo 1 · n = 4.200»). No les pongas nombre de negocio a los
grupos en la figura: nombrarlos puede ser una pregunta.

## Tipo 3 — Codo + silueta (semana 13)

El formato de la teoría, en un solo panel: **línea de la WCSS** (eje izquierdo, puntos marcados
con su valor) para k = 1…8, y **barras de la silueta promedio** (escala propia, rotulada cada
barra con su valor) para k = 2…8. Eje x: «número de clusters (k)». Una nota al pie dentro del SVG:
«línea: WCSS · barras: silueta promedio». No marques el codo con flecha ni resaltes ningún k:
encontrarlo es la pregunta.

## Tipo 4 — Gráficos del EDA (semana 6)

Uno de estos, según la pregunta:
- **Histograma** (bimodal, o con cola derecha y outliers), con líneas verticales punteadas del
  promedio y la mediana, rotuladas con su valor.
- **Barras por categoría**, incluyendo el error silencioso si la batería lo usa («Norte» y
  «norte» como barras separadas), cada barra con su conteo.
- **Boxplot por grupo** (2 a 4 grupos) con un punto fuera de los bigotes, rotulado con su valor.
- **Dispersión** de dos variables con un punto atípico rotulado.
Cada barra o tramo lleva su número encima: las preguntas se responden leyendo, no estimando a ojo.

## Tipo 5 — Matriz de confusión o comparación de modelos (semana 10)

La matriz dibujada como la vieron: 2×2 con encabezados «Predicho: X / Predicho: no X» y «Real: X /
Real: no X», cada celda con su rótulo (TP, FP, FN, TN) y su conteo grande. Para comparar dos
modelos: dos matrices lado a lado con el mismo test, o una tabla dibujada (modelo × envíos,
aciertos, errores). **No imprimas accuracy, precisión ni recall en la figura**: calcularlas es la
pregunta. El baseline («marcar a nadie» / «aprobar a todos») se describe en el contexto.

## Baterías de preguntas por tipo (encadenadas, dificultad creciente)

**Árbol** (la batería canónica del curso; úsala casi literal):
1. La profundidad y por qué (trampa: la rama corta).
2. El tamaño en hojas y cuáles son (trampa: «una por variable», contar nodos internos).
3. Ubicar un caso del entrenamiento en su hoja y leer su n (trampa: la hoja hermana, «el grupo más
   pequeño recibe los casos raros»).
4. El pronóstico (o la clase) para un caso NUEVO cuyo camino evita una pregunta llamativa — p. ej.
   tiene la característica de la hoja alta, pero su rama nunca la pregunta (trampa: la hoja
   llamativa, promediar dos hojas).
5. Un conteo por condición que obliga a sumar dos hojas de ramas distintas (trampas: una sola
   hoja, la rama entera, sumar la hoja equivocada).

**Clusters (dispersión):** 1. cuántos grupos y qué distingue a cada uno (leer ejes) · 2. leer el
centroide de un grupo (trampa: leer un punto extremo como el centroide, o el centroide como «un
cliente») · 3. a qué grupo se asigna el punto nuevo y por qué (distancia, no apariencia) · 4. qué
pasaría con esta figura si las variables no se hubieran escalado (la de rango grande domina) ·
5. qué acción de negocio recibe cada grupo / qué nombre le pones (trampa: nombres vacíos).

**Codo + silueta:** 1. qué k sugiere el codo y por qué (dónde deja de comprar, no dónde es mínima
la WCSS) · 2. qué k sugiere la silueta (el máximo) · 3. por qué la WCSS siempre baja y por eso no
se elige su mínimo · 4. qué hace el analista cuando codo y silueta discrepan (perfilar ambos;
decide el negocio) · 5. qué compra pasar de k al k+1 (leer la caída marginal).

**EDA:** 1. qué forma tiene la distribución y qué resumen la representa (trampa: el promedio de la
bimodal) · 2. leer una cifra puntual (un tramo, una barra, el outlier) · 3. qué significa para el
negocio el vacío / el outlier / la categoría duplicada · 4. qué decisión de limpieza procede y por
qué (trampa: eliminar en bloque, imputar sin preguntar) · 5. qué pasa con la conclusión si se
decide con la figura tal como está.

**Matriz / modelos:** 1. llenar o leer una celda (¿cuántos FP?) · 2. calcular una métrica con las
celdas (dos opciones comparten el número, difieren en el porqué) · 3. comparar contra el baseline
(trampa: la accuracy alta con clases desbalanceadas) · 4. qué métrica importa en ESTE negocio y
por qué (el costo del error) · 5. la decisión: qué modelo se adopta (o ninguno) dadas las cifras.

## Plan B cuando no se puede mostrar un SVG

1. Si el asistente puede ejecutar código y mostrar imágenes (p. ej. un intérprete de Python),
   genera la figura con matplotlib desde tu hoja de cifras, con los mismos rótulos.
2. Si no, dibuja en un bloque de texto monoespaciado: el árbol con cajas ASCII (número de nodo,
   valor, n, %, condición bajo el nodo), la matriz como tabla, el codo como tabla de k, WCSS y
   silueta, y los clusters como tabla de centroides y tamaños más una mini-descripción de la nube.
   Mantén la MISMA batería de preguntas: se responde leyendo la estructura, no el trazo.
