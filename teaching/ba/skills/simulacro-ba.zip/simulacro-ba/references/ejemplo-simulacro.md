# Un simulacro modelo, con su clave y su verificación

Esta es la vara. Un simulacro de la semana 5 tal como debe verse para el estudiante, luego la
clave tal como se entrega después de que responde, y por último la verificación de calibración
que se hace antes de enviarlo (esa parte nunca se le muestra al estudiante). Fíjate en tres cosas
que el parcial real exige: no aparece ninguna métrica ni se evalúa el modelo; cuando la pregunta
tiene una parte comprobable (la tarea, en la 2; el sí o no, en la 3), dos opciones la comparten y
se distinguen por el porqué; y se habla de roles, no de «el humano».

---

## Lo que ve el estudiante (mensaje 1)

### Simulacro · Semana 5 · El proceso analítico

**Contexto.** Una clínica odontológica de Cali con seis consultorios pierde cerca del 18 % de sus citas porque el paciente no llega y nadie avisa. La directora le dice al analista: «quiero entender el problema de las inasistencias». La clínica guarda tres años de citas con la hora, el tipo de procedimiento, la antigüedad del paciente, si confirmó por WhatsApp y si asistió o no. Una silla vacía cuesta la hora del odontólogo; una llamada de recordatorio cuesta dos minutos de la recepcionista. La directora quiere decidir a quién llamar el día anterior.

**1.** ¿Por qué «entender el problema de las inasistencias» todavía no es una pregunta de negocio?
a) Porque no dice qué haría la clínica distinto mañana con la respuesta: es un tema, no una pregunta.
b) Porque no menciona qué modelo se va a usar, y una pregunta de negocio nombra la técnica del análisis.
c) Porque las inasistencias no se pueden medir con las citas guardadas hasta que pase un año completo.
d) Porque la formuló la directora y no el analista, que es quien conoce los datos de la clínica.

**2.** ¿Qué tarea analítica corresponde a «¿qué pacientes no asistirán a su cita de mañana?», y qué lo confirma?
a) Predicción, porque la salida es el número de citas perdidas que tendrá la clínica cada día del mes.
b) Segmentación, porque agrupa a los pacientes según su riesgo sin necesidad de una etiqueta previa en la base.
c) Clasificación, porque la respuesta es sí o no, y el historial ya trae la columna de si asistió o no.
d) Clasificación, porque la directora separa a los pacientes en riesgo alto y bajo con un corte que fija ella.

**3.** La directora le pide al científico de datos que decida a partir de qué riesgo se llama a un paciente. ¿Es su papel?
a) Sí: el punto de corte es un parámetro técnico del modelo y lo fija quien lo construye a partir de los datos.
b) No: definir la decisión y el costo de cada error es del analista de negocio; el científico construye el modelo.
c) Sí, pero validado por el ingeniero de datos, que conoce la calidad de la columna de asistencia de la base.
d) No: debe decidirlo la recepcionista, porque es quien hace las llamadas y conoce a los pacientes que faltan.

**4.** El analista escribe en el informe: «el modelo identifica bien a la mayoría de los pacientes que no asistirán». ¿Qué le falta a esa frase para la directora?
a) El detalle técnico: qué variables usa el modelo, cómo se construyó y con cuántos años de citas de la clínica se probó.
b) El número, el costo y la acción: cuántas sillas vacías evita, cuánto cuestan las llamadas de más y a quién llamar mañana.
c) La validación de las recepcionistas, que conocen a los pacientes que suelen faltar y pueden confirmar la lista.
d) La comparación con otras clínicas de la ciudad, para mostrarle a la directora que el resultado es competitivo.

Responde con las cuatro letras, por ejemplo: 1b, 2d, 3a, 4c.

---

## La clave (mensaje 2, solo después de que respondió «1a, 2c, 3a, 4b»)

**1 → a** ✓  Si le entregan la respuesta hoy, nadie sabe qué hacer distinto mañana: es un tema.
*Por qué no las otras:* b confunde pregunta con técnica; c inventa una restricción; d confunde quién pregunta con qué se pregunta.
*Repasa:* «Etapa 1: formular la pregunta» y el test de la pregunta.

**2 → c** ✓  La respuesta es una categoría, asiste o no, y el historial ya trae esa etiqueta: por eso es clasificación.
*Por qué no las otras:* a pide un número, que es otra pregunta; b no tiene target, y aquí sí lo hay; d llama clasificación a un corte que fija la directora sin usar la etiqueta histórica, y eso no responde la pregunta que decide.
*Repasa:* «Tipos de tareas analíticas» y la pregunta que decide: ¿hay ejemplos históricos con la respuesta?

**3 → b** ✗  Contestaste a. Decidir a quién llamar y qué cuesta equivocarse en cada sentido (una hora de consultorio contra dos minutos de llamada) es del analista de negocio, que lidera la pregunta y la decisión; el científico de datos lidera una sola etapa, el modelo.
*Por qué no las otras:* a convierte una decisión de negocio en un parámetro técnico; c cambia de rol; d confunde a quien ejecuta la llamada con quien define la decisión.
*Repasa:* «Roles: quién lidera qué» y el caso churn, cómo trabajaron los cuatro.

**4 → b** ✓  A la directora se le habla con número, costo-beneficio y acción: sillas salvadas, costo de las llamadas y a quién llamar mañana. «Identifica bien» no le dice qué hacer.
*Por qué no las otras:* a y d cambian de tema; c no reemplaza el mensaje de negocio.
*Repasa:* «Etapa 6: comunicar los resultados».

**3 de 4.** Fallaste donde se decide quién lidera qué: vuelve a la tabla de roles antes de seguir.
¿Otro contexto de la semana 5, otra semana o el parcial completo?

---

## Verificación antes de enviar (no se muestra)

- Material abierto: teoría de la semana 5 y láminas de la clase; el contexto usa sus ideas (test de
  la pregunta, tarea analítica y su etiqueta histórica, roles, costo del error en palabras del
  negocio, comunicación) y ninguna de otra semana.
- Alcance: ninguna opción nombra una métrica ni evalúa el modelo; el costo del error aparece solo
  como la hora del odontólogo contra los dos minutos de la recepcionista.
- Decisión pendiente: a quién llamar el día anterior. Cifras usadas: 18 % (preguntas 2 y 4), la
  hora contra los dos minutos (preguntas 3 y 4).
- Interpretación, no definición: ninguna pregunta se responde recitando qué es una tarea analítica
  o qué hace cada rol.
- Parte comprobable compartida: en la 2, dos opciones dicen «Clasificación» y solo el porqué las
  separa; en la 3, dos dicen «Sí» y dos dicen «No».
- Roles, no «el humano»: analista de negocio, científico de datos, ingeniero de datos, recepcionista.
- Largo de las opciones por pregunta (caracteres): 1 → 98/101/99/93 (razón 1,09); 2 → 99/108/100/107 (razón 1,09); 3 → 108/111/106/107 (razón 1,05); 4 → 118/121/111/110 (razón 1,10). La correcta es la más larga en: la 3, por 3 caracteres; la 4, por 3 caracteres.
- Misma forma gramatical dentro de cada pregunta: explicaciones con «porque» en la 1 y la 2; Sí/No
  con su razón en la 3; sustantivos en la 4.
- Clave a c b b: sin tres iguales seguidas, sin escalera, sin alternancia; una letra repetida, así
  que no siempre salen las cuatro letras distintas.
- Dificultad: 1 y 2 de aplicación directa; 3 y 4 exigen decidir entre opciones razonables.
- Sector ficticio (clínica odontológica), sin Cóndor, sin empresas reales.
